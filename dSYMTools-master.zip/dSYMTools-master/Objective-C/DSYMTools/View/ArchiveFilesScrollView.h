//
//  ArchiveFilesScrollView.h
//  DSYMTools
//
//  Created by answer on 7/29/16.
//  Copyright © 2016 answer. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ArchiveFilesScrollView : NSScrollView
{
    BOOL highlight;
}


@end
