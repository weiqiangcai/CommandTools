# QiAppIconGenerator

使用原图生成各尺寸的图片，支持以下平台

1. iPhone AppIcons
2. iPhone LaunchImage Portrait
3. iPhone LaunchImages Landscape
4. iPad AppIcons
5. iPad LaunchImages Portrait
6. iPad LaunchImages Landscape
7. Mac AppIcons
8. Watch AppIcons
9. CarPlay AppIcons
10. Android AppIcons
11. Android LaunchImages Portrait
12. Android LaunchImages Landscape


# 使用演示


![01](/Source/QiAppIconGenerator_01.gif)
