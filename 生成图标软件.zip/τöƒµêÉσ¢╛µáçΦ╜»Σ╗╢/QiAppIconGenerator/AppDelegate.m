//
//  AppDelegate.m
//  QiAppIconGenerator
//
//  Created by huangxianshuai on 2019/3/19.
//  Copyright © 2019年 QiShare. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
