//
//  LuYaoPinManager.h
//  LuYaopin
//
//  Created by apple on 2020/3/10.
//  Copyright © 2020 LuYaopin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LuYaoPinManager : NSObject
+ (NSDictionary *)readLocalFileWithName:(NSString *)name;
@end

NS_ASSUME_NONNULL_END
